/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package agentes;

import java.awt.Image;
import javax.swing.ImageIcon;

/**
 *
 * @author Yomonki
 */
public class mother extends ImageIcon{
    String nombre;
    
    mother(Image imagen, String nombre){
        super(imagen);
        this.nombre = nombre;
    }
    
    @Override
    public boolean equals(Object other){
      mother otherImage = (mother) other;
      if (other == null) return false;
      return this.nombre==otherImage.nombre;
    }
}
