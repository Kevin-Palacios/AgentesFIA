/*0000  
0001
0010
0011
0100
0101
0110
0111=====
1000==========
1001
1010
1011
1100 ===========
1101=========
1110========
1111==========
 */
 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package agentes;

import java.net.URL;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

/**
 *
 * @author macario
 */
public class Agente extends Thread {

    String nombre;
    int i;
    int j;

    iconNew icon;
    int[][] matrix;
    JLabel tablero[][];

    JLabel casillaAnterior;
    Random aleatorio = new Random(System.currentTimeMillis());
    //Random direccion = new Random(System.currentTimeMillis());

    public Agente(String nombre, iconNew icon, int[][] matrix, JLabel tablero[][]) {
        this.nombre = nombre;
        this.icon = icon;
        this.matrix = matrix;
        this.tablero = tablero;

        this.i = aleatorio.nextInt(matrix.length);
        this.j = aleatorio.nextInt(matrix.length);
        tablero[i][j].setIcon(icon);
    }

    public void run() {
        iconNew nave;
        ArrayList navesx = new ArrayList<Integer>();
        ArrayList navesy = new ArrayList<Integer>();

        int pos = 0;
        for (int k = 0; k < matrix.length; k++) {
            for (int l = 0; l < matrix.length; l++) {
                nave = (iconNew) tablero[k][l].getIcon();
                if (tablero[k][l].getIcon() != null) {
                    if (nave.getPeso() == 2) {
                        System.out.println("Nave encontrada, x:" + k + " y: " + l);
                        navesx.add(k);
                        navesy.add(l);
                    }
                }

            }
        }

        int dirRow = 1;
        int dirCol = 1;      //F+,F-,C+,C-  
        int[] posObstaculos = {0, 0, 0, 0};
        ArrayList gradiente = new ArrayList<Integer>();
        gradiente.add(0);
        gradiente.add(0);
        gradiente.add(0);
        gradiente.add(0);

        boolean condicion = true;
        ImageIcon sample = new ImageIcon();
        int traeCoso = 0;
        while (condicion) {

            //boolean bandera = true;
            posObstaculos[0] = 0;
            posObstaculos[1] = 0;
            posObstaculos[2] = 0;
            posObstaculos[3] = 0;
            boolean bandera_cambia = true;

            iconNew muestra;
            int direccion = (int) (Math.random() * 2);

            int k;
            if (traeCoso == 1) {
                k = buscarNave(navesx, navesy);
                int disx = (int) navesx.get(k);
                int disy = (int) navesy.get(k);
                boolean sigo;
                sigo = true;
                while (sigo) {
                    gradiente.set(0, 0);
                    gradiente.set(1, 0);
                    gradiente.set(2, 0);
                    gradiente.set(3, 0);
                    boolean tomaDecision = false;
                    if (i < matrix.length - 1) {
                        if (tablero[i + 1][j].getIcon() != null) {
                            muestra = (iconNew) tablero[i + 1][j].getIcon();
                            gradiente.set(0, muestra.getPeso());
                        }
                    }
                    if (i > 0) {
                        if (tablero[i - 1][j].getIcon() != null) {
                            muestra = (iconNew) tablero[i - 1][j].getIcon();
                            gradiente.set(1, muestra.getPeso());
                        }
                    }
                    if (j < matrix.length - 1) {
                        if (tablero[i][j + 1].getIcon() != null) {
                            muestra = (iconNew) tablero[i][j + 1].getIcon();
                            gradiente.set(2, muestra.getPeso());
                        }
                    }
                    if (j > 0) {
                        if (tablero[i][j - 1].getIcon() != null) {
                            muestra = (iconNew) tablero[i][j - 1].getIcon();
                            gradiente.set(3, muestra.getPeso());
                        }
                    }
                    if (gradiente.contains(2)) {
                        sigo = false;
                    } else {
                        for (int l = 0; l < gradiente.size(); l++) {
                            if ((int) gradiente.get(l) == 3) {
                                gradiente.set(l, 1);
                            }
                        }

                        if ((int) gradiente.get(0) == 1 && (int) gradiente.get(1) == 1 && (int) gradiente.get(2) == 1 && (int) gradiente.get(3) == 1) {
                            break;

                        } else if ((int) gradiente.get(0) == 1 && (int) gradiente.get(1) == 1 && (int) gradiente.get(2) == 1 && (int) gradiente.get(3) == 0) {
                            dirCol = -1;
                            direccion = 0;
                            tomaDecision = false;
                        } else if ((int) gradiente.get(0) == 1 && (int) gradiente.get(1) == 1 && (int) gradiente.get(2) == 0 && (int) gradiente.get(3) == 1) {
                            dirCol = 1;
                            direccion = 0;
                            tomaDecision = false;
                        } else if ((int) gradiente.get(0) == 1 && (int) gradiente.get(1) == 1 && (int) gradiente.get(2) == 0 && (int) gradiente.get(3) == 0) {
                            direccion = 0;
                            tomaDecision = true;
                        } else if ((int) gradiente.get(0) == 1 && (int) gradiente.get(1) == 0 && (int) gradiente.get(2) == 1 && (int) gradiente.get(3) == 1) {
                            dirRow = -1;
                            direccion = 1;
                            tomaDecision = false;
                        } else if ((int) gradiente.get(0) == 1 && (int) gradiente.get(1) == 0 && (int) gradiente.get(2) == 1 && (int) gradiente.get(3) == 0) {
                            dirRow = -1;
                            dirCol = -1;
                            direccion = 3;
                            tomaDecision = true;
                        } else if ((int) gradiente.get(0) == 1 && (int) gradiente.get(1) == 0 && (int) gradiente.get(2) == 0 && (int) gradiente.get(3) == 1) {
                            dirRow = -1;
                            dirCol = 0;
                            direccion = 3;
                            tomaDecision = true;
                        } else if ((int) gradiente.get(0) == 1 && (int) gradiente.get(1) == 0 && (int) gradiente.get(2) == 0 && (int) gradiente.get(3) == 0) {
                            dirRow = -1;
                            dirCol = 1;
                            direccion = 3;
                            tomaDecision = true;
                        } else if ((int) gradiente.get(0) == 0 && (int) gradiente.get(1) == 1 && (int) gradiente.get(2) == 1 && (int) gradiente.get(3) == 1) {
                            dirRow = 1;
                            direccion = 0;
                            tomaDecision = false;
                        } else if ((int) gradiente.get(0) == 0 && (int) gradiente.get(1) == 1 && (int) gradiente.get(2) == 1 && (int) gradiente.get(3) == 0) {
                            dirRow = 1;
                            dirCol = -1;
                            direccion = 3;
                            tomaDecision = true;
                        } else if ((int) gradiente.get(0) == 0 && (int) gradiente.get(1) == 1 && (int) gradiente.get(2) == 0 && (int) gradiente.get(3) == 1) {
                            dirRow = 1;
                            dirCol = 1;
                            direccion = 3;
                            tomaDecision = true;
                        } else if ((int) gradiente.get(0) == 0 && (int) gradiente.get(1) == 1 && (int) gradiente.get(2) == 0 && (int) gradiente.get(3) == 0) {
                            dirRow = 1;
                            dirCol = 0;
                            direccion = 3;
                            tomaDecision = true;
                        } else if ((int) gradiente.get(0) == 0 && (int) gradiente.get(1) == 0 && (int) gradiente.get(2) == 1 && (int) gradiente.get(3) == 1) {
                            direccion = 1;
                            dirRow = 0;
                            tomaDecision = true;
                        } else if ((int) gradiente.get(0) == 0 && (int) gradiente.get(1) == 0 && (int) gradiente.get(2) == 1 && (int) gradiente.get(3) == 0) {
                            dirRow = 0;
                            dirCol = -1;
                            direccion = 3;
                            tomaDecision = true;
                        } else if ((int) gradiente.get(0) == 0 && (int) gradiente.get(1) == 0 && (int) gradiente.get(2) == 0 && (int) gradiente.get(3) == 1) {
                            dirRow = 0;
                            dirCol = 1;
                            direccion = 3;
                            tomaDecision = true;
                        } else if ((int) gradiente.get(0) == 0 && (int) gradiente.get(1) == 0 && (int) gradiente.get(2) == 0 && (int) gradiente.get(3) == 0) {
                            dirRow = 0;
                            dirCol = 1;
                            direccion = 3;
                            tomaDecision = true;
                        }
                        int aux1 = 0, aux2 = 0;

                        if (tomaDecision = true) {
                            if (direccion == 1 || direccion == 3) {
                                if (dirRow == 0) {
                                    if (disx - 1 < disx + 1) {
                                        dirRow = -1;

                                    } else {
                                        dirRow = 1;
                                    }
                                } else {
                                    aux1 = dirRow + disx;
                                }
                            }

                            if (direccion == 0 || direccion == 3) {
                                if (dirCol == 0) {
                                    if (disy - 1 < disy + 1) {
                                        dirCol = -1;

                                    } else {
                                        dirCol = 1;
                                    }
                                } else {
                                    aux2 = dirCol + disy;
                                }
                            }
                            if(aux1<aux2){
                                direccion=1;
                                        
                            }else{
                                direccion=0;
                            }
                        }
                        
                        casillaAnterior = tablero[i][j];
                        
                        if (direccion == 1) {
                            i = i + dirRow;
                            System.out.println(nombre + " DirRow: " + dirRow);
                        } else {
                            j = j + dirCol;
                            System.out.println(nombre + " DirCol: " + dirCol);
                        }
                        
                        actualizarPosicion(navesx, navesy);

                        try {

                            sleep(100 + aleatorio.nextInt(100));
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                    }
                }
            }
            //verificar si hay obstaculos a su alrededor antes de tomar una direccion

            if (i < matrix.length - 1) {
                if (tablero[i + 1][j].getIcon() != null) {
                    muestra = (iconNew) tablero[i + 1][j].getIcon();
                    if (muestra.getPeso() == 1 || (muestra.getPeso() == 3 && traeCoso == 1)) {
                        posObstaculos[0] = 1;
                    } else if (muestra.getPeso() == 2 && traeCoso == 1) {
                        traeCoso = 0;
                        dirRow = 1;
                        direccion = 1;
                        //condicion=false;
                        bandera_cambia = false;
                    }
                }

            } else {
                posObstaculos[0] = 1;
            }
            if (i > 0) {
                if (tablero[i - 1][j].getIcon() != null) {
                    muestra = (iconNew) tablero[i - 1][j].getIcon();
                    if (muestra.getPeso() == 1 || (muestra.getPeso() == 3 && traeCoso == 1)) {
                        posObstaculos[1] = 1;
                    } else if (muestra.getPeso() == 2 && traeCoso == 1) {
                        traeCoso = 0;
                        dirRow = -1;
                        direccion = 1;
                        //condicion=false;
                        bandera_cambia = false;
                    }
                }

            } else {
                posObstaculos[1] = 1;
            }
            if (j < matrix.length - 1) {
                if (tablero[i][j + 1].getIcon() != null) {
                    muestra = (iconNew) tablero[i][j + 1].getIcon();
                    if (muestra.getPeso() == 1 || (muestra.getPeso() == 3 && traeCoso == 1)) {
                        posObstaculos[2] = 1;

                    } else if (muestra.getPeso() == 2 && traeCoso == 1) {
                        traeCoso = 0;
                        dirCol = 1;
                        direccion = 0;
                        //condicion=false;
                        bandera_cambia = false;
                    }
                }

            } else {
                posObstaculos[2] = 1;
            }
            if (j > 0) {
                if (tablero[i][j - 1].getIcon() != null) {
                    muestra = (iconNew) tablero[i][j - 1].getIcon();
                    if (muestra.getPeso() == 1 || (muestra.getPeso() == 3 && traeCoso == 1)) {
                        posObstaculos[3] = 1;
                    } else if (muestra.getPeso() == 2 && traeCoso == 1) {
                        traeCoso = 0;
                        dirCol = -1;
                        direccion = 0;
                        //condicion=false;
                        bandera_cambia = false;
                    }
                }

            } else {
                posObstaculos[3] = 1;
            }
            System.out.println("&&&&&&&&&&&Arreglo " + nombre + ": " + posObstaculos[0] + ", " + posObstaculos[1] + ", " + posObstaculos[2] + ", " + posObstaculos[3]);
            //F+,F-,C+,C-
            if (posObstaculos[0] == 1 && posObstaculos[1] == 1 && posObstaculos[2] == 1 && posObstaculos[3] == 1) {
                break;

            } else if (posObstaculos[0] == 1 && posObstaculos[1] == 1 && posObstaculos[2] == 1 && posObstaculos[3] == 0) {
                dirCol = -1;
                direccion = 0;
                bandera_cambia = false;
            } else if (posObstaculos[0] == 1 && posObstaculos[1] == 1 && posObstaculos[2] == 0 && posObstaculos[3] == 1) {
                dirCol = 1;
                direccion = 0;
                bandera_cambia = false;
            } else if (posObstaculos[0] == 1 && posObstaculos[1] == 1 && posObstaculos[2] == 0 && posObstaculos[3] == 0) {
                direccion = 0;
            } else if (posObstaculos[0] == 1 && posObstaculos[1] == 0 && posObstaculos[2] == 1 && posObstaculos[3] == 1) {
                dirRow = -1;
                direccion = 1;
                bandera_cambia = false;
            } else if (posObstaculos[0] == 1 && posObstaculos[1] == 0 && posObstaculos[2] == 1 && posObstaculos[3] == 0) {
                dirRow = -1;
                dirCol = -1;
                bandera_cambia = false;
            } else if (posObstaculos[0] == 1 && posObstaculos[1] == 0 && posObstaculos[2] == 0 && posObstaculos[3] == 1) {
                dirRow = -1;
                dirCol = 1;
                bandera_cambia = false;
            } else if (posObstaculos[0] == 1 && posObstaculos[1] == 0 && posObstaculos[2] == 0 && posObstaculos[3] == 0) {
                dirRow = -1;
                bandera_cambia = false;
            } else if (posObstaculos[0] == 0 && posObstaculos[1] == 1 && posObstaculos[2] == 1 && posObstaculos[3] == 1) {
                dirRow = 1;
                direccion = 1;
                bandera_cambia = false;
            } else if (posObstaculos[0] == 0 && posObstaculos[1] == 1 && posObstaculos[2] == 1 && posObstaculos[3] == 0) {
                dirRow = 1;
                dirCol = -1;
                bandera_cambia = false;
            } else if (posObstaculos[0] == 0 && posObstaculos[1] == 1 && posObstaculos[2] == 0 && posObstaculos[3] == 1) {
                dirRow = 1;
                dirCol = 1;
                bandera_cambia = false;
            } else if (posObstaculos[0] == 0 && posObstaculos[1] == 1 && posObstaculos[2] == 0 && posObstaculos[3] == 0) {
                dirRow = 1;
                bandera_cambia = false;
            } else if (posObstaculos[0] == 0 && posObstaculos[1] == 0 && posObstaculos[2] == 1 && posObstaculos[3] == 1) {
                direccion = 1;
            } else if (posObstaculos[0] == 0 && posObstaculos[1] == 0 && posObstaculos[2] == 1 && posObstaculos[3] == 0) {
                dirCol = -1;
                bandera_cambia = false;
            } else if (posObstaculos[0] == 0 && posObstaculos[1] == 0 && posObstaculos[2] == 0 && posObstaculos[3] == 1) {
                dirCol = 1;
                bandera_cambia = false;
            }

            casillaAnterior = tablero[i][j];
            if (bandera_cambia) {
                System.out.println("*****Bandera cambia***********" + nombre);
                int numeroRow = (int) (Math.random() * 2);
                if (numeroRow == 1) {
                    dirRow = 1;
                } else {
                    dirRow = -1;
                }

                if (i > matrix.length - 2 && dirRow == 1) {
                    dirRow = -1;
                }
                if (i < 1 && dirRow == -1) {
                    dirRow = 1;
                }

                if (numeroRow == 1) {
                    dirCol = 1;
                } else {
                    dirCol = -1;
                }

                if (j > matrix.length - 2 && dirCol == 1) {
                    dirCol = -1;
                }
                if (j < 1 && dirCol == -1) {
                    dirCol = 1;
                }
            }
            //Recoje muestras

            if (traeCoso == 0) {

                if (i < matrix.length - 1) {
                    if (tablero[i + 1][j].getIcon() != null) {
                        muestra = (iconNew) tablero[i + 1][j].getIcon();
                        if (muestra.getPeso() == 3) {
                            dirRow = 1;
                            direccion = 1;
                            System.out.println(tablero[i + 1][j].getIcon());
                            traeCoso = 1;
                        }
                    }
                }

                if (i > 0) {
                    if (tablero[i - 1][j].getIcon() != null) {
                        muestra = (iconNew) tablero[i - 1][j].getIcon();
                        if (muestra.getPeso() == 3) {
                            dirRow = -1;
                            direccion = 1;
                            System.out.println(tablero[i - 1][j].getIcon());
                            traeCoso = 1;
                        }
                    }
                }
                if (j < matrix.length - 1) {
                    if (tablero[i][j + 1].getIcon() != null) {
                        muestra = (iconNew) tablero[i][j + 1].getIcon();
                        if (muestra.getPeso() == 3) {
                            dirCol = 1;
                            direccion = 0;
                            System.out.println(tablero[i][j + 1].getIcon());
                            traeCoso = 1;
                        }
                    }
                }

                if (j > 0) {
                    if (tablero[i][j - 1].getIcon() != null) {
                        muestra = (iconNew) tablero[i][j - 1].getIcon();
                        if (muestra.getPeso() == 3) {
                            System.out.println(tablero[i][j - 1].getIcon());
                            dirCol = -1;
                            direccion = 0;
                            traeCoso = 1;
                        }
                    }
                }
            }/*else{
                int index_menor;
                while(traeCoso!=0){
                    index_menor = buscarNave(navesx, navesy);
                    
                    int res = Math.abs(navesx.get(index_menor)-i);
                    Math.abs(navesx.get(1)-i);
                    if (9==0) {
                        
                    }
                    
                    
                }
            }*/

            int auxi = i;
            int auxj = j;
            //cuando direccion ==1 vamos a ir arriba o abajo, el signo de dirRow va a decir si arriba(-) o abajo(+)
            //cuando direccion ==0 vamos a ir izquierda o derecha, el signo de dirRow va a decir si izquierda(-) o derecha(+)
            if (direccion == 1) {
                i = i + dirRow;
                System.out.println(nombre + " DirRow: " + dirRow);
            } else {
                j = j + dirCol;
                System.out.println(nombre + " DirCol: " + dirCol);
            }

            actualizarPosicion(navesx, navesy);

            try {

                sleep(100 + aleatorio.nextInt(100));
            } catch (Exception ex) {
                ex.printStackTrace();
            }

        }

    }

    /*
    public static iconNew getIconNew(){
        URL urlImage = ClassLoader.getSystemResource("org/sunspotworld/heatsensors/icon/" + name + ".png");
        
    }
     */
    public synchronized void actualizarPosicion(ArrayList<Integer> navesx, ArrayList<Integer> navesy) {
        iconNew motherIcon;
        casillaAnterior.setIcon(null); // Elimina su figura de la casilla anterior
        motherIcon = new iconNew("imagenes/mothership.png");
        motherIcon = new iconNew(motherIcon.getImage().getScaledInstance(50, 50, java.awt.Image.SCALE_SMOOTH), 2);
        for (int k = 0; k < navesx.size(); k++) {
            tablero[navesx.get(k)][navesy.get(k)].setIcon(motherIcon);
        }
        tablero[i][j].setIcon(icon);
        System.out.println(nombre + " in -> Row: " + i + " Col:" + j);
    }

    public synchronized int buscarNave(ArrayList<Integer> navesx, ArrayList<Integer> navesy) {
        int index_menor = 0;
        int distancia = 0;
        int distanciaMenor = 100000;
        for (int k = 0; k < navesx.size(); k++) {

            distancia = Math.abs(navesx.get(k) - i) + Math.abs(navesy.get(k) - j);
            if (distancia < distanciaMenor) {
                distanciaMenor = distancia;
                index_menor = k;
            }
        }

        return index_menor;
    }

}
